import { drizzle } from "drizzle-orm/node-postgres";
import { migrate } from "drizzle-orm/node-postgres/migrator";
import pg from "pg";
import * as schema from "./shared/schema";

const { Pool } = pg;

async function runMigration() {
  const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
  });

  const db = drizzle(pool, { schema });
  
  // Run migrations
  console.log("Running migrations...");
  await migrate(db, { migrationsFolder: "./migrations" });

  // Cleanup
  await pool.end();
  console.log("Migrations completed.");
}

runMigration().catch(console.error);