import { useState, useEffect } from "react";
import Layout from "@/components/Layout";
import Notification from "@/components/Notification";
import { User } from "@shared/schema";
import { useSocket } from "@/lib/useSocket";

interface NotificationItem {
  id: string;
  title: string;
  message: string;
  user: User;
  type: "direct" | "channel";
}

export default function Chat() {
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const { registerHandler } = useSocket();
  
  // Get current user from localStorage
  const userDataStr = localStorage.getItem("user");
  const currentUser: User | null = userDataStr ? JSON.parse(userDataStr) : null;
  
  // Listen for new direct messages that should trigger notifications
  useEffect(() => {
    if (!currentUser) return;
    
    const unregister = registerHandler('new_message', (payload) => {
      // Only show notifications for direct messages sent to current user
      if (
        payload.recipientId === currentUser.id && 
        payload.userId !== currentUser.id
      ) {
        const notificationId = `msg-${Date.now()}`;
        setNotifications(prev => [
          ...prev, 
          {
            id: notificationId,
            title: payload.user.username,
            message: payload.content,
            user: payload.user,
            type: "direct"
          }
        ]);
      }
    });
    
    return unregister;
  }, [registerHandler, currentUser]);
  
  // Remove notification by id
  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };
  
  return (
    <>
      <Layout onLogout={() => window.location.reload()} />
      
      {/* Display notifications */}
      {notifications.map(notification => (
        <Notification
          key={notification.id}
          title={notification.title}
          message={notification.message}
          user={notification.user}
          type={notification.type}
          onClose={() => removeNotification(notification.id)}
        />
      ))}
    </>
  );
}
