import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Channel } from '@shared/schema';

export function useChannels() {
  const [selectedChannel, setSelectedChannel] = useState<Channel | null>(null);
  
  // Fetch all channels
  const channelsQuery = useQuery({
    queryKey: ['/api/channels'],
  });
  
  useEffect(() => {
    // Set default selected channel to first channel if available
    if (channelsQuery.data?.length && !selectedChannel) {
      setSelectedChannel(channelsQuery.data[0]);
    }
  }, [channelsQuery.data, selectedChannel]);
  
  return {
    channels: channelsQuery.data || [],
    isLoading: channelsQuery.isLoading,
    isError: channelsQuery.isError,
    selectedChannel,
    setSelectedChannel
  };
}
