import { useState, useEffect, useCallback } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest } from './queryClient';
import { useSocket } from './useSocket';
import { MessageWithUser } from '@shared/schema';
import { queryClient } from './queryClient';

interface SendMessageParams {
  content: string;
  userId: number;
  channelId?: number;
  recipientId?: number;
}

export function useMessages(channelId?: number, recipientId?: number, userId?: number) {
  const [messages, setMessages] = useState<MessageWithUser[]>([]);
  const [typingUsers, setTypingUsers] = useState<{ [key: number]: boolean }>({});
  const { registerHandler, sendMessage } = useSocket();
  
  // Fetch messages based on channel or direct message
  const messagesQuery = useQuery({
    queryKey: channelId 
      ? [`/api/channels/${channelId}/messages`] 
      : recipientId && userId 
        ? [`/api/messages/direct/${userId}/${recipientId}`]
        : ['empty-query'],
    enabled: !!(channelId || (recipientId && userId))
  });
  
  // Set messages from query result
  useEffect(() => {
    if (messagesQuery.data) {
      setMessages(Array.isArray(messagesQuery.data) ? messagesQuery.data : []);
    }
  }, [messagesQuery.data]);
  
  // Listen for new messages
  useEffect(() => {
    const unregister = registerHandler('new_message', (payload: MessageWithUser) => {
      // Add message if it belongs to current channel or direct message conversation
      if (
        (channelId && payload.channelId === channelId) || 
        (recipientId && userId && (
          (payload.userId === userId && payload.recipientId === recipientId) || 
          (payload.userId === recipientId && payload.recipientId === userId)
        ))
      ) {
        setMessages(prev => [...prev, payload]);
      }
    });
    
    return unregister;
  }, [registerHandler, channelId, recipientId, userId]);
  
  // Listen for typing status
  useEffect(() => {
    const unregister = registerHandler('typing', (payload) => {
      if (
        (channelId && payload.channelId === channelId) || 
        (recipientId && userId && payload.userId === recipientId && payload.recipientId === userId)
      ) {
        if (payload.isTyping) {
          setTypingUsers(prev => ({ ...prev, [payload.userId]: true }));
        } else {
          setTypingUsers(prev => {
            const newState = { ...prev };
            delete newState[payload.userId];
            return newState;
          });
        }
      }
    });
    
    return unregister;
  }, [registerHandler, channelId, recipientId, userId]);
  
  // Send a new message
  const sendMessageMutation = useMutation({
    mutationFn: async (params: SendMessageParams) => {
      // Send via WebSocket
      sendMessage('new_message', params);
      
      // Add message locally for immediate display
      const newMessage: MessageWithUser = {
        id: Date.now(), // Temporary ID
        content: params.content,
        userId: params.userId,
        channelId: params.channelId || null,
        recipientId: params.recipientId || null,
        createdAt: new Date(),
        user: {
          id: params.userId,
          username: 'You', // Will be updated from the server response
          status: 'online',
          password: '',
          avatar: null,
          createdAt: null
        }
      };
      
      setMessages(prev => [...prev, newMessage]);
      
      // Invalidate query to refresh messages
      if (params.channelId) {
        queryClient.invalidateQueries({ queryKey: [`/api/channels/${params.channelId}/messages`] });
      } else if (params.recipientId && params.userId) {
        queryClient.invalidateQueries({ queryKey: [`/api/messages/direct/${params.userId}/${params.recipientId}`] });
      }
      
      return { success: true };
    }
  });
  
  // Update typing status
  const setTyping = useCallback((isTyping: boolean) => {
    if (!userId) return;
    
    sendMessage('typing', {
      userId,
      channelId,
      recipientId,
      isTyping
    });
  }, [userId, channelId, recipientId, sendMessage]);
  
  return {
    messages,
    isLoading: messagesQuery.isLoading,
    isError: messagesQuery.isError,
    sendMessage: sendMessageMutation.mutate,
    typingUsers,
    setTyping
  };
}
