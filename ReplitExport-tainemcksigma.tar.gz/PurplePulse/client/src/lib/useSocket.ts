import { useEffect, useCallback, useRef } from 'react';
import { initSocket, onMessage, sendMessage, closeSocket } from './socket';

export function useSocket() {
  // Reference to prevent multiple pings
  const pingIntervalRef = useRef<number | null>(null);
  
  // Initialize socket on component mount and keep connection alive with ping
  useEffect(() => {
    // Initialize the socket connection
    initSocket();
    
    // Setup ping interval to keep connection alive
    const setupPing = () => {
      // Clear any existing ping interval
      if (pingIntervalRef.current) {
        window.clearInterval(pingIntervalRef.current);
      }
      
      // Send a ping every 30 seconds to keep the connection alive
      pingIntervalRef.current = window.setInterval(() => {
        sendMessage('ping', { timestamp: Date.now() });
      }, 30000);
    };
    
    // Setup the initial ping
    setupPing();
    
    // Event listener for visibility change to reconnect when tab becomes visible
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        console.log('Tab is visible, reconnecting if needed');
        initSocket();
        setupPing();
      }
    };
    
    // Add visibility change listener
    document.addEventListener('visibilitychange', handleVisibilityChange);
    
    // Cleanup
    return () => {
      // No need to close the socket on unmount as it should remain open for the app
      // But we should clear the ping interval
      if (pingIntervalRef.current) {
        window.clearInterval(pingIntervalRef.current);
        pingIntervalRef.current = null;
      }
      
      // Remove visibility change listener
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);
  
  // Reconnect with user authentication
  const connectWithAuth = useCallback((userId: number) => {
    // Make sure the socket is initialized
    initSocket();
    
    // Set the user as online
    sendMessage('user_status', { userId, status: 'online' });
    
    // Setup a heartbeat to maintain connection and presence
    const heartbeatInterval = window.setInterval(() => {
      sendMessage('user_status', { userId, status: 'online' });
    }, 60000); // Every minute
    
    // Store the heartbeat interval to clear it later
    return () => {
      window.clearInterval(heartbeatInterval);
    };
  }, []);
  
  // Register a message handler
  const registerHandler = useCallback((type: string, handler: (data: any) => void) => {
    return onMessage(type, handler);
  }, []);
  
  // Send a message through the socket
  const sendSocketMessage = useCallback((type: string, payload: any) => {
    // Ensure socket is connected before sending
    initSocket();
    sendMessage(type, payload);
  }, []);
  
  // Disconnect and clean up
  const disconnect = useCallback(() => {
    if (pingIntervalRef.current) {
      window.clearInterval(pingIntervalRef.current);
      pingIntervalRef.current = null;
    }
    closeSocket();
  }, []);
  
  return {
    connectWithAuth,
    registerHandler,
    sendMessage: sendSocketMessage,
    disconnect
  };
}
