let socket: WebSocket | null = null;
let messageQueue: string[] = [];
let reconnectInterval: number | null = null;
let reconnectAttempts = 0;
let pingInterval: number | null = null;
let lastPongTime = 0;
let isConnecting = false;

// Configuration constants
const MAX_RECONNECT_ATTEMPTS = 10;
const INITIAL_RECONNECT_DELAY = 1000;
const MAX_RECONNECT_DELAY = 30000;
const PING_INTERVAL = 15000; // 15 seconds (reduced from 30)
const PONG_TIMEOUT = 5000; // 5 seconds to consider connection dead if no pong (reduced from 10)

export type MessageHandler = (data: any) => void;
const messageHandlers: Record<string, MessageHandler[]> = {};

// Create WebSocket connection
export const initSocket = () => {
  // Prevent multiple simultaneous connection attempts
  if (isConnecting) return;
  
  // Only return if socket is actually open and functioning
  if (socket && socket.readyState === WebSocket.OPEN) return;
  
  // Mark that we're connecting to prevent multiple attempts
  isConnecting = true;
  
  try {
    // Close any existing socket that's in a bad state
    if (socket && socket.readyState !== WebSocket.OPEN) {
      socket.close();
      socket = null;
    }
    
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    console.log(`Connecting to WebSocket at ${wsUrl}`);
    socket = new WebSocket(wsUrl);
    
    socket.onopen = () => {
      console.log("WebSocket connection established");
      isConnecting = false;
      reconnectAttempts = 0;
      lastPongTime = Date.now(); // Initialize last pong time
      
      // Clear any pending reconnect timers
      if (reconnectInterval) {
        clearTimeout(reconnectInterval);
        reconnectInterval = null;
      }
      
      // Clear any existing ping interval
      if (pingInterval) {
        clearInterval(pingInterval);
      }
      
      // Setup ping interval to keep connection alive
      pingInterval = window.setInterval(() => {
        if (socket && socket.readyState === WebSocket.OPEN) {
          // Check if we've received a pong recently
          const now = Date.now();
          if (now - lastPongTime > PONG_TIMEOUT) {
            console.warn("No pong received within timeout, reconnecting...");
            
            // Force close and reconnect
            if (socket) {
              socket.close();
              socket = null;
            }
            
            // Clear ping interval
            if (pingInterval) {
              clearInterval(pingInterval);
              pingInterval = null;
            }
            
            // Trigger reconnect
            initSocket();
            return;
          }
          
          // Send ping
          console.log("Sending ping to keep connection alive");
          sendMessage("ping", { timestamp: now });
        }
      }, PING_INTERVAL);
      
      // Send any queued messages
      while (messageQueue.length > 0) {
        const message = messageQueue.shift();
        if (message && socket && socket.readyState === WebSocket.OPEN) {
          socket.send(message);
        }
      }
    };
    
    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        // Handle pong responses specifically for connection monitoring
        if (data.type === "pong") {
          const now = Date.now();
          lastPongTime = now;
          const elapsed = now - (data.payload?.timestamp || 0);
          console.log(`Received pong response (ping latency: ${elapsed}ms)`);
          return; // No need to call other handlers for pong
        }
        
        // Call all handlers for this message type
        if (data.type && messageHandlers[data.type]) {
          messageHandlers[data.type].forEach(handler => handler(data.payload));
        }
      } catch (error) {
        console.error("Error parsing WebSocket message:", error);
      }
    };
    
    socket.onclose = (event) => {
      console.log(`WebSocket connection closed: code=${event.code}, reason=${event.reason}`);
      isConnecting = false;
      
      // Clear ping interval on close
      if (pingInterval) {
        clearInterval(pingInterval);
        pingInterval = null;
      }
      
      // Attempt reconnection with exponential backoff
      if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
        const delay = Math.min(
          INITIAL_RECONNECT_DELAY * Math.pow(1.5, reconnectAttempts), 
          MAX_RECONNECT_DELAY
        );
        reconnectAttempts++;
        
        console.log(`Scheduling reconnect in ${delay}ms (attempt ${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS})`);
        
        if (reconnectInterval) clearTimeout(reconnectInterval);
        reconnectInterval = window.setTimeout(() => {
          console.log(`Attempting to reconnect (${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS})...`);
          initSocket();
        }, delay);
      } else {
        console.error("Maximum WebSocket reconnection attempts reached");
      }
    };
    
    socket.onerror = (error) => {
      console.error("WebSocket error:", error);
      // Don't set isConnecting false here, let the onclose handler do it
    };
  } catch (error) {
    console.error("Error initializing WebSocket:", error);
    isConnecting = false;
  }
};

// Send a message through the WebSocket
export const sendMessage = (type: string, payload: any) => {
  const message = JSON.stringify({ type, payload });
  
  if (socket && socket.readyState === WebSocket.OPEN) {
    socket.send(message);
  } else {
    // Queue message for when connection is established
    messageQueue.push(message);
    
    // Try to reconnect if not already attempting
    if (!reconnectInterval) {
      initSocket();
    }
  }
};

// Register a message handler
export const onMessage = (type: string, handler: MessageHandler) => {
  if (!messageHandlers[type]) {
    messageHandlers[type] = [];
  }
  
  messageHandlers[type].push(handler);
  
  // Return function to remove the handler
  return () => {
    if (messageHandlers[type]) {
      const index = messageHandlers[type].indexOf(handler);
      if (index !== -1) {
        messageHandlers[type].splice(index, 1);
      }
    }
  };
};

// Close WebSocket connection
export const closeSocket = () => {
  if (socket) {
    socket.close();
    socket = null;
  }
  
  // Clear all timers and intervals
  if (reconnectInterval) {
    clearTimeout(reconnectInterval);
    reconnectInterval = null;
  }
  
  if (pingInterval) {
    clearInterval(pingInterval);
    pingInterval = null;
  }
  
  // Reset state
  messageQueue = [];
  reconnectAttempts = 0;
  lastPongTime = 0;
  isConnecting = false;
  
  // Clear all message handlers
  for (const type in messageHandlers) {
    messageHandlers[type] = [];
  }
};
