import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { User } from '@shared/schema';
import { useSocket } from './useSocket';

export function useDirectMessages(currentUserId?: number) {
  const [users, setUsers] = useState<User[]>([]);
  const [userStatuses, setUserStatuses] = useState<Record<number, string>>({});
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const { registerHandler } = useSocket();
  
  // Fetch all users
  const usersQuery = useQuery({
    queryKey: ['/api/users'],
  });
  
  useEffect(() => {
    if (usersQuery.data) {
      // Filter out current user
      const filteredUsers = usersQuery.data.filter(user => user.id !== currentUserId);
      setUsers(filteredUsers);
      
      // Initialize user statuses
      const initialStatuses: Record<number, string> = {};
      filteredUsers.forEach(user => {
        initialStatuses[user.id] = user.status || 'offline';
      });
      setUserStatuses(initialStatuses);
    }
  }, [usersQuery.data, currentUserId]);
  
  // Listen for user status changes
  useEffect(() => {
    const unregister = registerHandler('user_status', (payload) => {
      if (payload.userId && payload.status) {
        setUserStatuses(prev => ({
          ...prev,
          [payload.userId]: payload.status
        }));
      }
    });
    
    return unregister;
  }, [registerHandler]);
  
  // Get users with their status
  const usersWithStatus = users.map(user => ({
    ...user,
    status: userStatuses[user.id] || 'offline'
  }));
  
  return {
    users: usersWithStatus,
    isLoading: usersQuery.isLoading,
    isError: usersQuery.isError,
    selectedUser,
    setSelectedUser
  };
}
