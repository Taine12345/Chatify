import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Custom CSS for the pattern background and animations
const style = document.createElement("style");
style.textContent = `
  /* Background pattern */
  .bg-pattern {
    background-image: radial-gradient(rgba(108, 99, 255, 0.1) 2px, transparent 2px);
    background-size: 30px 30px;
  }
  
  /* Gradient animations */
  .gradient-animation {
    background: linear-gradient(-45deg, #6C63FF, #3F8CFF, #A45BFF, #6C63FF);
    background-size: 400% 400%;
    animation: gradientBG 15s ease infinite;
  }
  
  @keyframes gradientBG {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
  }
  
  /* Message bubble animation */
  .message-appear {
    animation: messageFadeIn 0.3s ease-in-out;
  }
  
  @keyframes messageFadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
  
  /* Notification animation */
  .ping {
    animation: ping 1.5s cubic-bezier(0, 0, 0.2, 1) infinite;
  }
  
  @keyframes ping {
    75%, 100% {
      transform: scale(1.5);
      opacity: 0;
    }
  }
  
  /* Scrollbar styling */
  ::-webkit-scrollbar {
    width: 6px;
    height: 6px;
  }
  
  ::-webkit-scrollbar-track {
    background: hsl(var(--surface));
  }
  
  ::-webkit-scrollbar-thumb {
    background: hsl(var(--primary));
    border-radius: 3px;
  }
`;

document.head.appendChild(style);

createRoot(document.getElementById("root")!).render(<App />);
