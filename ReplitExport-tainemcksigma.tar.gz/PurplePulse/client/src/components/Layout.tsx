import { useState, useEffect } from "react";
import Sidebar from "./Sidebar";
import ChannelsSidebar from "./ChannelsSidebar";
import MembersPanel from "./MembersPanel";
import MessageArea from "./MessageArea";
import MessageInput from "./MessageInput";
import { useSocket } from "@/lib/useSocket";
import { useChannels } from "@/lib/useChannels";
import { useDirectMessages } from "@/lib/useDirectMessages";
import { useMessages } from "@/lib/useMessages";
import { User } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import useMobile from "@/hooks/use-mobile";

interface LayoutProps {
  onLogout: () => void;
}

export default function Layout({ onLogout }: LayoutProps) {
  const [currentTab, setCurrentTab] = useState<"channels" | "direct">("channels");
  const [showMobileNav, setShowMobileNav] = useState(false);
  const [showMobileSidebar, setShowMobileSidebar] = useState(false);
  const { isMobile } = useMobile();
  const { toast } = useToast();
  
  // Get current user from localStorage
  const userDataStr = localStorage.getItem("user");
  const currentUser: User | null = userDataStr ? JSON.parse(userDataStr) : null;
  
  const { connectWithAuth, disconnect } = useSocket();
  const { channels, selectedChannel, setSelectedChannel } = useChannels();
  const { users, selectedUser, setSelectedUser } = useDirectMessages(currentUser?.id);
  
  // Handle messaging based on selected channel or direct message
  const { 
    messages, 
    sendMessage, 
    typingUsers,
    setTyping 
  } = useMessages(
    currentTab === "channels" ? selectedChannel?.id : undefined,
    currentTab === "direct" ? selectedUser?.id : undefined,
    currentUser?.id
  );
  
  // Connect to WebSocket with user authentication
  useEffect(() => {
    if (currentUser?.id) {
      connectWithAuth(currentUser.id);
    }
  }, [currentUser?.id, connectWithAuth]);
  
  // Handle logout
  const handleLogout = () => {
    disconnect();
    localStorage.removeItem("user");
    onLogout();
    toast({
      title: "Logged out",
      description: "You have been successfully logged out.",
    });
  };
  
  // Handle sending a message
  const handleSendMessage = (content: string) => {
    if (!content.trim() || !currentUser) return;
    
    if (currentTab === "channels" && selectedChannel) {
      sendMessage({
        content,
        userId: currentUser.id,
        channelId: selectedChannel.id
      });
    } else if (currentTab === "direct" && selectedUser) {
      sendMessage({
        content,
        userId: currentUser.id,
        recipientId: selectedUser.id
      });
    }
  };
  
  return (
    <div className="flex h-screen overflow-hidden bg-pattern">
      {/* Main sidebar (always visible on desktop, toggle on mobile) */}
      <Sidebar 
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        currentUser={currentUser}
        onLogout={handleLogout}
        visible={!isMobile || showMobileNav}
      />
      
      {/* Channels sidebar (visible on tablet+ or when toggled) */}
      <ChannelsSidebar
        channels={channels}
        selectedChannel={selectedChannel}
        setSelectedChannel={setSelectedChannel}
        users={users}
        selectedUser={selectedUser}
        setSelectedUser={setSelectedUser}
        currentTab={currentTab}
        visible={!isMobile || (isMobile && showMobileSidebar)}
        onClose={() => setShowMobileSidebar(false)}
      />
      
      {/* Main content area - always visible */}
      <div className="flex-1 flex flex-col">
        {/* Chat header */}
        <div className="h-14 border-b border-border flex items-center px-4 bg-card z-10">
          <div className="flex items-center">
            {isMobile && (
              <Button 
                variant="ghost" 
                size="icon" 
                className="mr-2 md:hidden"
                onClick={() => {
                  setShowMobileNav(!showMobileNav);
                  setShowMobileSidebar(!showMobileSidebar);
                }}
              >
                <i className="ri-menu-line text-xl"></i>
              </Button>
            )}
            <span className="text-primary font-medium mr-2">
              {currentTab === "channels" ? "#" : ""}
            </span>
            <h1 className="font-heading font-semibold">
              {currentTab === "channels" 
                ? selectedChannel?.name || "Select a channel" 
                : selectedUser?.username || "Select a user"}
            </h1>
          </div>
          <div className="ml-4 text-sm text-muted-foreground">
            {currentTab === "channels" && "Channel"}
          </div>
        </div>
        
        {/* Message area */}
        <MessageArea 
          messages={messages} 
          currentUser={currentUser}
          typingUsers={typingUsers}
          users={users} 
        />
        
        {/* Message input */}
        <MessageInput 
          onSendMessage={handleSendMessage}
          placeholder={
            currentTab === "channels" 
              ? `Message #${selectedChannel?.name || "channel"}` 
              : `Message ${selectedUser?.username || "user"}`
          }
          onTyping={setTyping}
        />
      </div>
      
      {/* Members panel (only visible on xl+ screens) */}
      <MembersPanel 
        users={users}
        currentUser={currentUser}
      />
      
      {/* Mobile navigation bar */}
      {isMobile && (
        <div className="md:hidden fixed bottom-0 left-0 right-0 h-14 bg-card border-t border-border flex items-center justify-around z-20">
          <button 
            className={`flex-1 h-full flex items-center justify-center ${currentTab === "channels" ? "text-primary" : "text-muted-foreground"}`}
            onClick={() => setCurrentTab("channels")}
          >
            <i className="ri-group-line text-xl"></i>
          </button>
          <button 
            className={`flex-1 h-full flex items-center justify-center ${currentTab === "direct" ? "text-primary" : "text-muted-foreground"} relative`}
            onClick={() => setCurrentTab("direct")}
          >
            <i className="ri-chat-private-line text-xl"></i>
          </button>
          <button 
            className="flex-1 h-full flex items-center justify-center text-muted-foreground"
          >
            <i className="ri-notification-line text-xl"></i>
          </button>
          <button 
            className="flex-1 h-full flex items-center justify-center text-muted-foreground"
            onClick={handleLogout}
          >
            <i className="ri-logout-box-line text-xl"></i>
          </button>
        </div>
      )}
    </div>
  );
}
