import { Channel, User } from "@shared/schema";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import UserAvatar from "./UserAvatar";
import { cn } from "@/lib/utils";
import { useState } from "react";

interface ChannelsSidebarProps {
  channels: Channel[];
  selectedChannel: Channel | null;
  setSelectedChannel: (channel: Channel) => void;
  users: User[];
  selectedUser: User | null;
  setSelectedUser: (user: User) => void;
  currentTab: "channels" | "direct";
  visible: boolean;
  onClose: () => void;
}

export default function ChannelsSidebar({
  channels,
  selectedChannel,
  setSelectedChannel,
  users,
  selectedUser,
  setSelectedUser,
  currentTab,
  visible,
  onClose
}: ChannelsSidebarProps) {
  const [searchQuery, setSearchQuery] = useState("");
  
  // Filter channels and users based on search query
  const filteredChannels = channels.filter(channel =>
    channel.name.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const filteredUsers = users.filter(user =>
    user.username.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  return (
    <div className={cn(
      "flex-col w-56 bg-card border-r border-border",
      visible ? "flex" : "hidden"
    )}>
      {/* Channels/DM header */}
      <div className="p-4 border-b border-border">
        <div className="flex justify-between items-center">
          <h2 className="font-heading font-semibold text-lg">
            {currentTab === "channels" ? "Channels" : "Direct Messages"}
          </h2>
          {/* Mobile close button */}
          <Button
            variant="ghost"
            size="sm"
            className="lg:hidden"
            onClick={onClose}
          >
            <i className="ri-close-line text-xl"></i>
          </Button>
        </div>
      </div>
      
      {/* Search */}
      <div className="p-3">
        <div className="bg-accent/20 rounded-md flex items-center px-3 py-1.5">
          <i className="ri-search-line text-muted-foreground mr-2"></i>
          <Input
            type="text"
            placeholder="Search"
            className="bg-transparent border-none w-full text-sm focus:outline-none text-foreground"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>
      
      {currentTab === "channels" ? (
        <>
          {/* Channels list */}
          <div className="flex-1 overflow-y-auto py-2">
            {filteredChannels.map(channel => (
              <button
                key={channel.id}
                className={cn(
                  "flex items-center w-full py-2 px-3 rounded-lg mx-1 text-left group",
                  selectedChannel?.id === channel.id
                    ? "bg-primary/20"
                    : "hover:bg-primary/10"
                )}
                onClick={() => setSelectedChannel(channel)}
              >
                <span 
                  className={cn(
                    "mr-2",
                    selectedChannel?.id === channel.id
                      ? "text-primary"
                      : "text-primary text-opacity-80 group-hover:text-opacity-100"
                  )}
                >
                  #
                </span>
                <span 
                  className={cn(
                    "text-sm",
                    selectedChannel?.id === channel.id
                      ? "font-medium text-foreground"
                      : "text-muted-foreground"
                  )}
                >
                  {channel.name}
                </span>
              </button>
            ))}
          </div>
        </>
      ) : (
        <>
          {/* Direct messages list */}
          <div className="flex-1 overflow-y-auto py-2">
            {filteredUsers.map(user => (
              <button
                key={user.id}
                className={cn(
                  "flex items-center w-full py-2 px-3 rounded-lg mx-1 text-left",
                  selectedUser?.id === user.id
                    ? "bg-secondary/20"
                    : "hover:bg-primary/10"
                )}
                onClick={() => setSelectedUser(user)}
              >
                <div className="relative flex-shrink-0">
                  <UserAvatar user={user} className="w-7 h-7" />
                </div>
                <span 
                  className={cn(
                    "text-sm ml-2",
                    selectedUser?.id === user.id
                      ? "font-medium text-foreground"
                      : "text-muted-foreground"
                  )}
                >
                  {user.username}
                </span>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
