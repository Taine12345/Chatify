import { User } from "@shared/schema";
import UserAvatar from "./UserAvatar";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { useEffect, useState } from "react";

interface NotificationProps {
  title: string;
  message: string;
  user: User;
  onClose: () => void;
  type: "direct" | "channel";
}

export default function Notification({ 
  title, 
  message, 
  user, 
  onClose,
  type
}: NotificationProps) {
  const [visible, setVisible] = useState(true);
  
  // Auto-hide notification after 5 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      setVisible(false);
      setTimeout(onClose, 300); // Allow animation to finish
    }, 5000);
    
    return () => clearTimeout(timer);
  }, [onClose]);
  
  if (!visible) return null;
  
  return (
    <div 
      className={cn(
        "fixed top-5 right-5 bg-card border border-border rounded-lg shadow-lg p-4 w-72 flex items-start z-30 message-appear",
        !visible && "opacity-0 transition-opacity duration-300"
      )}
    >
      <div className="relative flex-shrink-0 mr-3">
        <UserAvatar user={user} className="w-10 h-10" />
      </div>
      <div className="flex-1">
        <div className="flex justify-between items-center">
          <h4 className="font-medium text-sm">{title}</h4>
          <span className="text-xs text-muted-foreground">now</span>
        </div>
        <p className="text-sm text-muted-foreground mt-1">{message}</p>
        <div className="text-xs text-secondary mt-1">
          {type === "direct" ? "Direct Message" : "Channel Message"}
        </div>
      </div>
    </div>
  );
}
