import { User } from "@shared/schema";
import UserAvatar from "./UserAvatar";

interface MembersPanelProps {
  users: User[];
  currentUser: User | null;
}

export default function MembersPanel({ users, currentUser }: MembersPanelProps) {
  // Separate users by status
  const onlineUsers = users.filter(user => user.status === "online");
  const offlineUsers = users.filter(user => user.status === "offline" || user.status === "away");
  
  return (
    <div className="hidden xl:flex flex-col w-56 bg-card border-l border-border">
      {/* Members header */}
      <div className="p-4 border-b border-border">
        <h2 className="font-heading font-semibold text-lg">Members</h2>
      </div>
      
      {/* Online members */}
      <div className="p-4 border-b border-border">
        <h3 className="text-xs font-medium text-muted-foreground mb-3 uppercase">
          Online - {onlineUsers.length}
        </h3>
        <div className="space-y-3">
          {onlineUsers.map(user => (
            <div key={user.id} className="flex items-center">
              <div className="relative">
                <UserAvatar user={user} className="w-7 h-7" />
              </div>
              <span className={cn(
                "text-sm ml-2",
                currentUser?.id === user.id ? "font-medium text-primary" : ""
              )}>
                {currentUser?.id === user.id ? "You" : user.username}
              </span>
            </div>
          ))}
          
          {/* Always show current user if logged in */}
          {currentUser && !onlineUsers.some(u => u.id === currentUser.id) && (
            <div className="flex items-center">
              <div className="relative">
                <UserAvatar user={currentUser} className="w-7 h-7" />
              </div>
              <span className="text-sm ml-2 font-medium text-primary">You</span>
            </div>
          )}
        </div>
      </div>
      
      {/* Offline members */}
      <div className="p-4 flex-1 overflow-y-auto">
        <h3 className="text-xs font-medium text-muted-foreground mb-3 uppercase">
          Offline - {offlineUsers.length}
        </h3>
        <div className="space-y-3">
          {offlineUsers.map(user => (
            <div key={user.id} className="flex items-center">
              <div className="relative">
                <UserAvatar user={user} className="w-7 h-7" />
              </div>
              <span className="text-sm ml-2 text-muted-foreground">
                {user.username}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// Utility function to conditionally join classNames
function cn(...classes: (string | boolean | undefined)[]): string {
  return classes.filter(Boolean).join(' ');
}
