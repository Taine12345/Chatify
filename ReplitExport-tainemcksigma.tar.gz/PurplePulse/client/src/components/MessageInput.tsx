import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

interface MessageInputProps {
  onSendMessage: (message: string) => void;
  placeholder: string;
  onTyping: (isTyping: boolean) => void;
}

export default function MessageInput({ 
  onSendMessage, 
  placeholder,
  onTyping
}: MessageInputProps) {
  const [message, setMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const typingTimeoutRef = useRef<number | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  
  // Handle typing status
  useEffect(() => {
    if (message && !isTyping) {
      setIsTyping(true);
      onTyping(true);
    }
    
    // Clear previous timeout
    if (typingTimeoutRef.current) {
      window.clearTimeout(typingTimeoutRef.current);
    }
    
    // Set timeout to clear typing status after 2 seconds of inactivity
    typingTimeoutRef.current = window.setTimeout(() => {
      if (isTyping) {
        setIsTyping(false);
        onTyping(false);
      }
    }, 2000);
    
    return () => {
      if (typingTimeoutRef.current) {
        window.clearTimeout(typingTimeoutRef.current);
      }
    };
  }, [message, isTyping, onTyping]);
  
  const handleSubmit = () => {
    if (message.trim()) {
      setIsSending(true);
      
      try {
        onSendMessage(message);
        setMessage("");
        // Clear typing state
        setIsTyping(false);
        onTyping(false);
        
        // Force focus back to textarea for continuous typing
        if (textareaRef.current) {
          textareaRef.current.focus();
        }
      } catch (error) {
        console.error("Error sending message:", error);
      } finally {
        setIsSending(false);
      }
    }
  };
  
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    // Send on Enter without Shift
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };
  
  return (
    <div className="p-4 backdrop-blur-md border-t border-white/10">
      <div className="flex items-center message-input rounded-xl p-1">
        <div className="flex gap-1">
          <Button variant="ghost" size="icon" className="text-purple-300/70 hover:text-purple-300 hover:bg-purple-500/10">
            <i className="ri-add-line text-xl"></i>
          </Button>
          
          <Button variant="ghost" size="icon" className="text-purple-300/70 hover:text-purple-300 hover:bg-purple-500/10">
            <i className="ri-emotion-line text-xl"></i>
          </Button>
        </div>
        
        <Textarea
          ref={textareaRef}
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          className="flex-1 bg-transparent border-none px-3 py-2 focus:outline-none focus:ring-0 resize-none max-h-32 text-white text-base font-medium"
          style={{ textShadow: 'none' }}
          rows={1}
        />
        
        <div className="flex gap-1">
          <Button variant="ghost" size="icon" className="text-purple-300/70 hover:text-purple-300 hover:bg-purple-500/10">
            <i className="ri-attachment-2 text-xl"></i>
          </Button>
          
          <Button 
            className={`glow-effect bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg px-4 py-2 ml-1 flex items-center justify-center gap-1 transition-all ${isSending ? 'opacity-70' : 'hover:shadow-lg'}`}
            onClick={handleSubmit}
            disabled={isSending || !message.trim()}
          >
            {isSending ? (
              <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <>
                <span className="hidden sm:inline">Send</span>
                <i className="ri-send-plane-fill text-lg"></i>
              </>
            )}
          </Button>
        </div>
      </div>
      
      {/* Typing indicator */}
      <div className="h-5 px-2 mt-1">
        {isTyping && (
          <p className="text-xs text-purple-300/60 italic">You are typing...</p>
        )}
      </div>
    </div>
  );
}
