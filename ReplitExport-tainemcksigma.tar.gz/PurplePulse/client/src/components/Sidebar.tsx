import { User } from "@shared/schema";
import UserAvatar from "./UserAvatar";
import { cn } from "@/lib/utils";

interface SidebarProps {
  currentTab: "channels" | "direct";
  setCurrentTab: (tab: "channels" | "direct") => void;
  currentUser: User | null;
  onLogout: () => void;
  visible: boolean;
}

export default function Sidebar({ 
  currentTab, 
  setCurrentTab, 
  currentUser,
  onLogout,
  visible
}: SidebarProps) {
  return (
    <div className={cn(
      "flex-col w-16 bg-card border-r border-border flex-shrink-0",
      visible ? "flex" : "hidden"
    )}>
      {/* App logo */}
      <div className="p-3 flex justify-center">
        <div className="w-10 h-10 rounded-xl gradient-animation flex items-center justify-center text-white font-bold">
          <i className="ri-chat-4-fill text-xl"></i>
        </div>
      </div>
      
      {/* Navigation items */}
      <div className="flex-1 flex flex-col items-center py-4 space-y-6">
        <button 
          className={cn(
            "w-10 h-10 rounded-xl flex items-center justify-center",
            currentTab === "channels" 
              ? "bg-primary text-primary-foreground" 
              : "hover:bg-accent text-muted-foreground hover:text-accent-foreground"
          )}
          onClick={() => setCurrentTab("channels")}
        >
          <i className="ri-group-line text-xl"></i>
        </button>
        <button 
          className={cn(
            "w-10 h-10 rounded-xl flex items-center justify-center relative",
            currentTab === "direct" 
              ? "bg-primary text-primary-foreground" 
              : "hover:bg-accent text-muted-foreground hover:text-accent-foreground"
          )}
          onClick={() => setCurrentTab("direct")}
        >
          <i className="ri-chat-private-line text-xl"></i>
          {/* We could add notification dot here in future versions */}
        </button>
        <button className="w-10 h-10 rounded-xl hover:bg-accent flex items-center justify-center text-muted-foreground hover:text-accent-foreground">
          <i className="ri-notification-line text-xl"></i>
        </button>
        <button 
          className="w-10 h-10 rounded-xl hover:bg-accent flex items-center justify-center text-muted-foreground hover:text-accent-foreground"
          onClick={onLogout}
        >
          <i className="ri-logout-box-line text-xl"></i>
        </button>
      </div>
      
      {/* User profile */}
      <div className="p-3 flex justify-center">
        <div className="relative">
          <UserAvatar 
            user={currentUser}
            className="w-10 h-10 border-2 border-accent"
          />
        </div>
      </div>
    </div>
  );
}
