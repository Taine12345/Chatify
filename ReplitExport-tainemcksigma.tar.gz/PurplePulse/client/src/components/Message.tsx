import { MessageWithUser } from "@shared/schema";
import UserAvatar from "./UserAvatar";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

interface MessageProps {
  message: MessageWithUser;
  isCurrentUser: boolean;
  showUserInfo: boolean;
}

export default function Message({ message, isCurrentUser, showUserInfo }: MessageProps) {
  // Format timestamp
  const timestamp = message.createdAt 
    ? format(new Date(message.createdAt), "h:mm a")
    : "";
  
  // System message with extreme glow
  if (!message.user) {
    return (
      <div className="flex justify-center message-appear">
        <div className="relative bg-gradient-to-r from-purple-800/50 to-blue-800/50 rounded-full px-6 py-2 text-base text-white glow-effect shadow-2xl overflow-hidden">
          {/* Base animation layers */}
          <div className="absolute inset-0 bg-gradient-to-r from-purple-600/30 via-blue-500/20 to-purple-600/30 animate-pulse"></div>
          <div className="absolute inset-0 bg-gradient-to-tr from-fuchsia-500/20 via-transparent to-blue-500/20 animate-pulse" style={{animationDelay: '0.7s'}}></div>
          
          {/* Multiple glow layers */}
          <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-purple-600/50 to-blue-600/50 blur-md"></div>
          <div className="absolute -inset-2 rounded-full bg-gradient-to-r from-fuchsia-600/40 to-indigo-600/40 blur-lg"></div>
          <div className="absolute -inset-3 rounded-full bg-gradient-to-r from-violet-600/30 to-blue-600/30 blur-xl"></div>
          <div className="absolute -inset-4 rounded-full bg-gradient-to-r from-purple-600/20 to-blue-600/20 blur-2xl"></div>
          
          {/* Content with extreme glow */}
          <span className="ultra-glow-text relative z-10 font-medium">{message.content}</span>
          
          {/* Extra shine effect */}
          <div className="absolute inset-0 rounded-full overflow-hidden">
            <div className="absolute top-0 left-1/4 right-1/4 h-1/2 bg-gradient-to-b from-white/20 to-transparent rounded-full"></div>
          </div>
          
          {/* Moving particle effect */}
          <div className="particles-container"></div>
        </div>
      </div>
    );
  }
  
  // User message
  return (
    <div className="flex items-start space-x-3 message-appear">
      {showUserInfo && (
        <UserAvatar 
          user={message.user} 
          className="w-10 h-10 mt-1" 
        />
      )}
      
      {!showUserInfo && (
        <div className="w-10"></div>
      )}
      
      <div className="flex-1">
        {showUserInfo && (
          <div className="flex items-baseline">
            <h3 className={cn(
              "font-medium",
              isCurrentUser ? "text-primary" : ""
            )}>
              {isCurrentUser ? "You" : message.user.username}
            </h3>
            <span className="ml-2 text-xs text-muted-foreground">
              {timestamp}
            </span>
          </div>
        )}
        
        <div className={cn(
          "relative text-foreground mt-1 px-4 py-2 rounded-xl glow-effect shadow-2xl glowing-message-bubble transition-all duration-300 transform hover:scale-[1.05]",
          isCurrentUser 
            ? "bg-gradient-to-r from-purple-900/70 via-indigo-800/70 to-blue-900/70" 
            : "bg-gradient-to-r from-blue-900/70 via-indigo-800/70 to-purple-900/70"
        )}>
          {/* Base layer */}
          <div className="absolute inset-0 rounded-xl bg-black/20 backdrop-blur-sm"></div>
          
          {/* Multiple animated gradient overlays */}
          <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-purple-600/30 via-blue-500/20 to-purple-600/30 animate-pulse opacity-80"></div>
          <div className="absolute inset-0 rounded-xl bg-gradient-to-tr from-fuchsia-600/20 via-transparent to-blue-600/20 animate-pulse opacity-70" style={{animationDelay: '0.5s'}}></div>
          <div className="absolute inset-0 rounded-xl bg-gradient-to-bl from-violet-600/20 via-transparent to-indigo-600/20 animate-pulse opacity-60" style={{animationDelay: '1s'}}></div>
          
          {/* Outer glow layers */}
          <div className="absolute -inset-0.5 rounded-xl bg-gradient-to-r from-purple-600/50 to-blue-600/50 blur-md"></div>
          <div className="absolute -inset-1 rounded-xl bg-gradient-to-r from-fuchsia-600/40 to-indigo-600/40 blur-lg"></div>
          <div className="absolute -inset-2 rounded-xl bg-gradient-to-r from-violet-600/30 to-blue-600/30 blur-xl"></div>
          <div className="absolute -inset-3 rounded-xl bg-gradient-to-r from-purple-600/20 to-blue-600/20 blur-2xl"></div>
          
          {/* Extra shine effect */}
          <div className="absolute inset-0 rounded-xl overflow-hidden">
            <div className="absolute inset-0 rounded-xl bg-gradient-to-tr from-white/10 via-white/5 to-transparent"></div>
          </div>
          
          {/* Text content with extreme glow */}
          <p className="ultra-glow-text text-white font-medium text-lg relative z-10">{message.content}</p>
          
          {/* Hover reveal glow layer (activated on hover) */}
          <div className="absolute inset-0 bg-gradient-to-r from-purple-600/0 to-blue-600/0 rounded-xl blur-2xl pointer-events-none opacity-0 transition-opacity duration-300 group-hover:opacity-100"></div>
        </div>
      </div>
    </div>
  );
}
