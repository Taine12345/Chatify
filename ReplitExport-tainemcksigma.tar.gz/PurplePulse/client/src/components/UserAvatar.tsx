import { User } from "@shared/schema";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";

interface UserAvatarProps {
  user: User | null;
  className?: string;
}

export default function UserAvatar({ user, className }: UserAvatarProps) {
  if (!user) {
    return (
      <Avatar className={className}>
        <AvatarFallback>?</AvatarFallback>
      </Avatar>
    );
  }
  
  // Get user status color
  const getStatusColor = (status: string) => {
    switch (status) {
      case "online": return "bg-emerald-500"; // online green
      case "away": return "bg-orange-500";    // away orange
      case "offline": return "bg-slate-400";  // offline gray
      default: return "bg-slate-400";
    }
  };
  
  // Get initials from username
  const getInitials = (name: string) => {
    return name.charAt(0).toUpperCase();
  };
  
  return (
    <div className="relative">
      <Avatar className={className}>
        {user.avatar ? (
          <img src={user.avatar} alt={user.username} />
        ) : (
          <AvatarFallback className="bg-accent">
            {getInitials(user.username)}
          </AvatarFallback>
        )}
      </Avatar>
      
      <span className={cn(
        "absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-card",
        getStatusColor(user.status || "offline")
      )}></span>
    </div>
  );
}
