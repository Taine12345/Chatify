import { useState, useEffect } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { useToast } from "@/hooks/use-toast";
import Chat from "@/pages/Chat";
import Login from "@/pages/Login";
import NotFound from "@/pages/not-found";

function Router() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const { toast } = useToast();
  
  useEffect(() => {
    // Check for existing authentication
    const userData = localStorage.getItem("user");
    if (userData) {
      try {
        const user = JSON.parse(userData);
        if (user && user.id) {
          setIsAuthenticated(true);
        }
      } catch (error) {
        localStorage.removeItem("user");
        toast({
          title: "Session Error",
          description: "Your session is invalid. Please login again.",
          variant: "destructive"
        });
      }
    }
  }, [toast]);

  return (
    <Switch>
      <Route path="/">
        {isAuthenticated ? <Chat /> : <Login onLoginSuccess={() => setIsAuthenticated(true)} />}
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
