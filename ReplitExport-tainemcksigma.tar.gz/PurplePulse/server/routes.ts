import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertChannelSchema, 
  insertMessageSchema,
  User
} from "@shared/schema";
import { z } from "zod";

// Define the WebSocket message types
type WebSocketMessageType = 
  | "new_message" 
  | "user_status" 
  | "typing"
  | "error"
  | "ping"
  | "pong";

interface WebSocketMessage {
  type: WebSocketMessageType;
  payload: any;
}

// Track connected users
interface ConnectedClient {
  socket: WebSocket;
  userId: number; // Must be a valid number (not null)
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  const clients: ConnectedClient[] = [];
  
  // Set up WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  wss.on("connection", (socket) => {
    let userId: number | null = null;
    
    socket.on("message", async (message) => {
      try {
        const data = JSON.parse(message.toString()) as WebSocketMessage;
        
        // Handle different message types
        switch (data.type) {
          case "user_status":
            if (data.payload && data.payload.userId && data.payload.status) {
              userId = data.payload.userId;
              
              // Only add to clients if userId is a valid number (not null)
              if (typeof userId === 'number' && !clients.some(client => client.userId === userId)) {
                clients.push({ socket, userId: userId });
              }
              
              // Update user status - handle null safety
              if (typeof userId === 'number') {
                const updatedUser = await storage.updateUserStatus(userId, data.payload.status);
              
                // Broadcast status change to all clients
                broadcastToAll({
                  type: "user_status",
                  payload: { userId, status: data.payload.status }
                });
              }
            }
            break;
            
          case "new_message":
            if (!userId) {
              socket.send(JSON.stringify({
                type: "error",
                payload: { message: "Not authenticated" }
              }));
              break;
            }
            
            try {
              // Validate message data
              const validatedData = insertMessageSchema.parse(data.payload);
              
              // Create the message
              const message = await storage.createMessage({
                ...validatedData,
                userId
              });
              
              // Get user data to include with message
              const user = await storage.getUser(userId);
              
              // Broadcast to appropriate clients
              if (message.channelId) {
                // Public channel message - broadcast to all
                broadcastToAll({
                  type: "new_message",
                  payload: { ...message, user }
                });
              } else if (message.recipientId) {
                // Direct message - send only to recipient and sender
                broadcastToUser(message.recipientId, {
                  type: "new_message",
                  payload: { ...message, user }
                });
                
                // Also send to sender to update their UI
                broadcastToUser(userId, {
                  type: "new_message",
                  payload: { ...message, user }
                });
              }
            } catch (error) {
              socket.send(JSON.stringify({
                type: "error",
                payload: { message: "Invalid message format" }
              }));
            }
            break;
            
          case "typing":
            if (!userId) break;
            
            if (data.payload.channelId) {
              // Broadcast typing status to all for channel
              broadcastToAll({
                type: "typing",
                payload: {
                  userId,
                  channelId: data.payload.channelId,
                  isTyping: data.payload.isTyping
                }
              });
            } else if (data.payload.recipientId) {
              // Send typing status only to recipient
              broadcastToUser(data.payload.recipientId, {
                type: "typing",
                payload: {
                  userId,
                  recipientId: data.payload.recipientId,
                  isTyping: data.payload.isTyping
                }
              });
            }
            break;
          
          case "ping":
            // Respond to keep-alive pings immediately
            if (socket.readyState === WebSocket.OPEN) {
              try {
                console.log("Received ping, sending pong");
                // Send pong with minimal delay
                const pongResponse = JSON.stringify({
                  type: "pong",
                  payload: { timestamp: Date.now() }
                });
                socket.send(pongResponse);
                
                // If we have a userId, update last seen time
                if (typeof userId === 'number') {
                  // Update user status to ensure they're marked as online
                  storage.updateUserStatus(userId, "online").catch(err => {
                    console.error("Error updating user status:", err);
                  });
                }
              } catch (error) {
                console.error("Error sending pong response:", error);
              }
            }
            break;
            
          default:
            socket.send(JSON.stringify({
              type: "error",
              payload: { message: "Unknown message type" }
            }));
        }
      } catch (error) {
        console.error("WebSocket message error:", error);
        socket.send(JSON.stringify({
          type: "error",
          payload: { message: "Invalid message format" }
        }));
      }
    });
    
    socket.on("close", () => {
      if (typeof userId === 'number') {
        // Update user status to offline
        storage.updateUserStatus(userId, "offline");
        
        // Remove from clients array
        const index = clients.findIndex(client => client.userId === userId);
        if (index !== -1) {
          clients.splice(index, 1);
        }
        
        // Notify other clients
        broadcastToAll({
          type: "user_status",
          payload: { userId, status: "offline" }
        });
      }
    });
  });
  
  // Helper functions for WebSocket broadcasting
  function broadcastToAll(message: WebSocketMessage) {
    const messageStr = JSON.stringify(message);
    clients.forEach(client => {
      if (client.socket.readyState === WebSocket.OPEN) {
        client.socket.send(messageStr);
      }
    });
  }
  
  function broadcastToUser(userId: number, message: WebSocketMessage) {
    const messageStr = JSON.stringify(message);
    const client = clients.find(client => client.userId === userId);
    if (client && client.socket.readyState === WebSocket.OPEN) {
      client.socket.send(messageStr);
    }
  }
  
  // Set up REST API routes
  app.post("/api/users/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already taken" });
      }
      
      // Create new user
      const newUser = await storage.createUser(userData);
      
      // Return user without password
      const { password, ...userWithoutPassword } = newUser;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create user" });
    }
  });
  
  app.post("/api/users/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password required" });
      }
      
      // Find user
      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Return user without password
      const { password: _, ...userWithoutPassword } = user;
      res.status(200).json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Login failed" });
    }
  });
  
  app.get("/api/users", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      
      // Remove passwords before sending
      const usersWithoutPasswords = users.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      
      res.status(200).json(usersWithoutPasswords);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve users" });
    }
  });
  
  app.get("/api/channels", async (req, res) => {
    try {
      const channels = await storage.getAllChannels();
      res.status(200).json(channels);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve channels" });
    }
  });
  
  app.post("/api/channels", async (req, res) => {
    try {
      const channelData = insertChannelSchema.parse(req.body);
      
      // Check if channel already exists
      const existingChannel = await storage.getChannelByName(channelData.name);
      if (existingChannel) {
        return res.status(400).json({ message: "Channel name already taken" });
      }
      
      const newChannel = await storage.createChannel(channelData);
      res.status(201).json(newChannel);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid channel data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create channel" });
    }
  });
  
  app.get("/api/channels/:channelId/messages", async (req, res) => {
    try {
      const channelId = parseInt(req.params.channelId);
      if (isNaN(channelId)) {
        return res.status(400).json({ message: "Invalid channel ID" });
      }
      
      const messages = await storage.getChannelMessages(channelId);
      res.status(200).json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve messages" });
    }
  });
  
  app.get("/api/messages/direct/:userId/:recipientId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const recipientId = parseInt(req.params.recipientId);
      
      if (isNaN(userId) || isNaN(recipientId)) {
        return res.status(400).json({ message: "Invalid user or recipient ID" });
      }
      
      const messages = await storage.getDirectMessages(userId, recipientId);
      res.status(200).json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve direct messages" });
    }
  });
  
  return httpServer;
}
