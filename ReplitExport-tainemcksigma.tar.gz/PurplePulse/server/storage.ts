import { 
  type User, 
  type InsertUser, 
  type Channel, 
  type InsertChannel, 
  type Message, 
  type InsertMessage, 
  type MessageWithUser
} from "@shared/schema";

// Storage interface for all CRUD operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStatus(id: number, status: string): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  
  // Channel operations
  getChannel(id: number): Promise<Channel | undefined>;
  getChannelByName(name: string): Promise<Channel | undefined>;
  createChannel(channel: InsertChannel): Promise<Channel>;
  getAllChannels(): Promise<Channel[]>;
  
  // Message operations
  createMessage(message: InsertMessage): Promise<Message>;
  getChannelMessages(channelId: number): Promise<MessageWithUser[]>;
  getDirectMessages(userId: number, recipientId: number): Promise<MessageWithUser[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private channels: Map<number, Channel>;
  private messages: Map<number, Message>;
  private userIdCounter: number;
  private channelIdCounter: number;
  private messageIdCounter: number;

  constructor() {
    this.users = new Map();
    this.channels = new Map();
    this.messages = new Map();
    this.userIdCounter = 1;
    this.channelIdCounter = 1;
    this.messageIdCounter = 1;
    
    // Add default channels
    this.createChannel({ name: "general", description: "General discussion channel" });
    this.createChannel({ name: "random", description: "Random topics and discussions" });
    this.createChannel({ name: "support", description: "Help and support channel" });
    this.createChannel({ name: "announcements", description: "Important announcements" });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase()
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      status: "offline",
      avatar: null,
      createdAt: now
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateUserStatus(id: number, status: string): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, status };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Channel operations
  async getChannel(id: number): Promise<Channel | undefined> {
    return this.channels.get(id);
  }

  async getChannelByName(name: string): Promise<Channel | undefined> {
    return Array.from(this.channels.values()).find(
      (channel) => channel.name.toLowerCase() === name.toLowerCase()
    );
  }

  async createChannel(insertChannel: InsertChannel): Promise<Channel> {
    const id = this.channelIdCounter++;
    const now = new Date();
    const channel: Channel = { 
      ...insertChannel, 
      id, 
      createdAt: now,
      description: insertChannel.description || null 
    };
    this.channels.set(id, channel);
    return channel;
  }
  
  async getAllChannels(): Promise<Channel[]> {
    return Array.from(this.channels.values());
  }

  // Message operations
  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.messageIdCounter++;
    const now = new Date();
    const message: Message = { 
      ...insertMessage, 
      id, 
      createdAt: now,
      channelId: insertMessage.channelId || null,
      recipientId: insertMessage.recipientId || null
    };
    this.messages.set(id, message);
    return message;
  }

  async getChannelMessages(channelId: number): Promise<MessageWithUser[]> {
    const channelMessages = Array.from(this.messages.values())
      .filter(msg => msg.channelId === channelId)
      .sort((a, b) => {
        // Safe check for null createdAt
        const timeA = a.createdAt ? a.createdAt.getTime() : 0;
        const timeB = b.createdAt ? b.createdAt.getTime() : 0;
        return timeA - timeB;
      });
    
    return Promise.all(
      channelMessages.map(async msg => {
        const user = await this.getUser(msg.userId);
        return { ...msg, user: user! };
      })
    );
  }

  async getDirectMessages(userId: number, recipientId: number): Promise<MessageWithUser[]> {
    const directMessages = Array.from(this.messages.values())
      .filter(msg => 
        (msg.userId === userId && msg.recipientId === recipientId) || 
        (msg.userId === recipientId && msg.recipientId === userId)
      )
      .sort((a, b) => {
        // Safe check for null createdAt
        const timeA = a.createdAt ? a.createdAt.getTime() : 0;
        const timeB = b.createdAt ? b.createdAt.getTime() : 0;
        return timeA - timeB;
      });
    
    return Promise.all(
      directMessages.map(async msg => {
        const user = await this.getUser(msg.userId);
        return { ...msg, user: user! };
      })
    );
  }
}

// Database implementation removed as requested

// Initialize storage with in-memory implementation
export const storage = new MemStorage();
