// This is a dummy file since we're using memory storage instead of a database
// No database connection is needed
